#ifndef MEMORY_H
#define MEMORY_H


class Memory
{
public:
    Memory();
    double memoryRequest();
};

#endif // MEMORY_H
