#ifndef CPU_H
#define CPU_H


class cpu
{
public:
    cpu();
    double cpuPcent(void);
};

#endif // CPU_H
